package ua.stetsenkoinna.libnetannotation.processor;

import ua.stetsenkoinna.libnetannotation.annotation.NetLibraryMethod;

import javax.annotation.processing.*;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;
import java.util.Set;

@SupportedAnnotationTypes("ua.stetsenkoinna.libnetannotation.annotation.NetLibraryMethod")
@SupportedSourceVersion(SourceVersion.RELEASE_23)
public class NetLibraryMethodProcessor extends AbstractProcessor {

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        Types typeUtils = processingEnv.getTypeUtils();
        Elements elementUtils = processingEnv.getElementUtils();
        for (Element element : roundEnv.getElementsAnnotatedWith(NetLibraryMethod.class)) {
            if (element instanceof ExecutableElement method) {
                if (!method.getParameters().isEmpty()) {
                    processingEnv.getMessager().printMessage(
                            Diagnostic.Kind.ERROR,
                            "Method " + method.getSimpleName() + " should have no parameters",
                            method
                    );
                }
                if (!typeUtils.isSameType(method.getReturnType(), elementUtils.getTypeElement("ua.stetsenkoinna.petriobj.PetriNet").asType())) {
                    processingEnv.getMessager().printMessage(
                            Diagnostic.Kind.ERROR,
                            "Method " + method.getSimpleName() + " should return ua.stetsenkoinna.petriobj.PetriNet",
                            method
                    );
                }
            } else {
                processingEnv.getMessager().printMessage(
                        Diagnostic.Kind.ERROR, "Only methods can be tagged with NetLibraryMethod"
                );
            }
        }
        return true;
    }
}
