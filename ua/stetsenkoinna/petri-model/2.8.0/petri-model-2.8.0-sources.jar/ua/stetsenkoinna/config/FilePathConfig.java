package ua.stetsenkoinna.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Centralized file path configuration for the application.
 * Provides cross-platform file path resolution for NetLibrary and other external files.
 *
 * @author Serhii Rybak
 */
public class FilePathConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(FilePathConfig.class);
    private static final Properties properties = new Properties();

    // Default path configurations (fallback if properties file is not found)
    private static final String[] DEFAULT_NET_LIBRARY_PATHS = {
        "petri-math/src/main/java/ua/stetsenkoinna/libnet/NetLibrary.java",
        "src/main/java/ua/stetsenkoinna/libnet/NetLibrary.java",
        "src/libnet/NetLibrary.java"
    };

    static {
        loadProperties();
    }

    /**
     * Load properties from application.properties file
     */
    private static void loadProperties() {
        try (InputStream input = FilePathConfig.class.getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (input != null) {
                properties.load(input);
            } else {
                LOGGER.warn("application.properties not found, using default paths");
            }
        } catch (IOException e) {
            LOGGER.warn("Failed to load application.properties, using default paths", e);
        }
    }

    /**
     * Get the path to NetLibrary.java file, searching through configured paths
     * until a valid file is found.
     *
     * @return Path to NetLibrary.java or null if not found
     */
    public static Path getNetLibraryPath() {
        String userDir = System.getProperty("user.dir");

        // Try custom path from properties first
        String customPath = properties.getProperty("netlibrary.path");
        if (customPath != null && !customPath.isEmpty()) {
            Path path = Paths.get(userDir, customPath);
            if (Files.exists(path)) {
                LOGGER.info("Found NetLibrary.java at custom path: {}", path);
                return path;
            }
        }

        // Try default paths
        for (String pathStr : DEFAULT_NET_LIBRARY_PATHS) {
            Path path = Paths.get(userDir, pathStr);
            if (Files.exists(path)) {
                LOGGER.info("Found NetLibrary.java at: {}", path);
                return path;
            }
        }

        LOGGER.error("NetLibrary.java not found in any configured path. Working directory: {}", userDir);
        return null;
    }

    /**
     * Get the path to NetLibrary.java file as a string.
     *
     * @return Path string to NetLibrary.java or null if not found
     */
    public static String getNetLibraryPathString() {
        Path path = getNetLibraryPath();
        return path != null ? path.toString() : null;
    }

    /**
     * Check if NetLibrary.java exists at any configured location.
     *
     * @return true if NetLibrary.java is found, false otherwise
     */
    public static boolean netLibraryExists() {
        return getNetLibraryPath() != null;
    }

    /**
     * Get all configured NetLibrary search paths for debugging purposes.
     *
     * @return Array of search path strings
     */
    public static String[] getNetLibrarySearchPaths() {
        String userDir = System.getProperty("user.dir");
        String customPath = properties.getProperty("netlibrary.path");

        if (customPath != null && !customPath.isEmpty()) {
            String[] paths = new String[DEFAULT_NET_LIBRARY_PATHS.length + 1];
            paths[0] = Paths.get(userDir, customPath).toString();
            for (int i = 0; i < DEFAULT_NET_LIBRARY_PATHS.length; i++) {
                paths[i + 1] = Paths.get(userDir, DEFAULT_NET_LIBRARY_PATHS[i]).toString();
            }
            return paths;
        }

        String[] paths = new String[DEFAULT_NET_LIBRARY_PATHS.length];
        for (int i = 0; i < DEFAULT_NET_LIBRARY_PATHS.length; i++) {
            paths[i] = Paths.get(userDir, DEFAULT_NET_LIBRARY_PATHS[i]).toString();
        }
        return paths;
    }
}