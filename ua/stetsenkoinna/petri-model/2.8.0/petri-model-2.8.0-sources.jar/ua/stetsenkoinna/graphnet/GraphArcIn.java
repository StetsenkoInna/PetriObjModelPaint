package ua.stetsenkoinna.graphnet;

import ua.stetsenkoinna.petriobj.ArcIn;
import ua.stetsenkoinna.theme.CanvasPalette;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Инна
 */
public class GraphArcIn extends GraphArc implements Serializable {

    /** Pinned for the same reason as {@link GraphArc#serialVersionUID}. */
    private static final long serialVersionUID = -3456795803948160223L;

    private final ArcIn arc;

    private static ArrayList<GraphArcIn> graphArcInList = new ArrayList<>();
  
    public GraphArcIn() {
        super();
        arc = new ArcIn();
        super.setLineWidth(1);
        super.setColor(Color.BLACK);
    }
        
    public GraphArcIn(ArcIn arcin){
        arc = arcin;
        super.setLineWidth(1);
        super.setColor(Color.BLACK);
   
    }
    public ArcIn getArcIn()
    {
    return arc;
    }

    @Override
    public void setPetriElements() {
        arc.setQuantity(arc.getQuantity());
        arc.setInf(arc.getIsInf());
        arc.setNumP(super.getBeginElement().getNumber());
        arc.setNumT(super.getEndElement().getNumber());
        arc.setNameP(super.getBeginElement().getName());
        arc.setNameT(super.getEndElement().getName());

        addElementToArrayList();
    }

    @Override
    public void addElementToArrayList() {
        if (graphArcInList == null) {
            graphArcInList = new ArrayList<>();
        }
        graphArcInList.add(this);
    }

    @Override
    public void drawGraphElement(Graphics2D g) {
        Graphics2D g2 = (Graphics2D) g;
        // Set for both kinds of arc. The dashed inhibitor branch used to leave the colour to
        // whatever the previous element happened to leave on the graphics, which was invisible
        // while everything on the canvas was black anyway and stops being so the moment a second
        // palette exists.
        g2.setColor(CanvasPalette.current().strokeFor(getColor()));
        if (arc.getIsInf()) {
            Stroke drawingStroke = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{4, 4}, 0);
            g2.setStroke(drawingStroke);
        } else {
            g2.setStroke(new BasicStroke(getLineWidth()));
        }
        g2.draw(this.getGraphElement());
        drawArrowHead(g2);
        if (arc.getQuantity() != 1 || arc.kIsParam()) {
            String quantityString = arc.kIsParam()
                ? arc.getKParamName()
                : Integer.toString(arc.getQuantity());
            this.getAvgLine().setLocation((this.getGraphElement().getX1() + this.getGraphElement().getX2()) / 2, (this.getGraphElement().getY1() + this.getGraphElement().getY2()) / 2);
            g2.drawLine((int) this.getAvgLine().getX() + 5, (int) this.getAvgLine().getY() - 5, (int) this.getAvgLine().getX() - 5, (int) this.getAvgLine().getY() + 5);

            // shift two arcs
            float textX = (float) this.getAvgLine().getX();
            float textY = (float) this.getAvgLine().getY() - 7;
            if (this.isFirstArc()) {
                textX -= 10; // left shift for the first arc
                textY -= 5;  // upper shift
            } else if (this.isSecondArc()) {
                textX += 10; // right shift for the second arc
                textY += 5;  // down shift
            }
            g2.drawString(quantityString, textX, textY);
        }
    }
    
    public static ArrayList<GraphArcIn> getGraphArcInList() {
        return graphArcInList;
    }

    public static ArrayList<ArcIn> getArcInList() {
        ArrayList<ArcIn> arrayArcIn = new ArrayList <>();
        for (GraphArcIn e: graphArcInList)
            arrayArcIn.add(e.getArcIn());
        return arrayArcIn;
    }

    public static void setNullArcInList() {
        graphArcInList.clear();
    }
  
    @Override
    public int getQuantity(){
            return arc.getQuantity();
        }

    @Override
    public void setQuantity(int i){
        arc.setQuantity(i);
    }

    @Override
    public boolean getIsInf(){
        return arc.getIsInf();
    }

    @Override
    public void setInf(boolean i){
        arc.setInf(i);
    }

    public static void addGraphArcInList(List<GraphArcIn> tieIn){ // added by Olha 14/11/2012
        graphArcInList.addAll(tieIn);
    }
}
