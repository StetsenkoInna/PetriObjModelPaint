package ua.stetsenkoinna.graphnet;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import ua.stetsenkoinna.theme.CanvasColor;
import ua.stetsenkoinna.theme.CanvasPalette;

public class GraphPlace extends GraphElement {

    /**
     * Pinned alongside {@link GraphElement}'s own id: a concrete class's default id depends only
     * on its own declared shape, not its superclass, so nothing here is actually changing yet -
     * but every place on a saved canvas is one of these, so it gets the same safety net rather
     * than staying one accidental field away from breaking every file on disk.
     */
    private static final long serialVersionUID = 3105490110026436094L;

    private static int diameter = 40;

    public static int getDiameter() { return diameter; }
    public static void setDiameter(int aDiameter) { diameter = aDiameter; }

    private Ellipse2D graphElement = new Ellipse2D.Double(0, 0, getDiameter(), getDiameter());

    public GraphPlace() {
        super.setLineWidth(3);
        super.setColor(Color.BLACK);
    }

    /**
     * Whether this place is linked to another, and so holds a marking it does not own alone.
     *
     * <p>Transient and derived: {@code GraphCanvasModel.syncFusions} states it afresh from the
     * links on every pass rather than anything maintaining it, so it cannot drift out of step
     * with them, and a file written before this existed reads back without it. Deriving rather
     * than accumulating is the same rule the two-way arc pairing follows, and for the same
     * reason - a flag that is only ever set and never cleared is wrong the moment a link goes.
     */
    private transient boolean linkedToAnotherPlace;

    /**
     * @param linked true if some link makes this place share its marking
     */
    public void setLinkedToAnotherPlace(boolean linked) {
        this.linkedToAnotherPlace = linked;
    }

    /**
     * @return whether this place shares its marking with another
     */
    public boolean isLinkedToAnotherPlace() {
        return linkedToAnotherPlace;
    }

    /**
     * <p>Leaves {@code g2} set to the outline colour on the way out, which is not tidiness but
     * contract: {@link GraphPetriPlace} draws its name and marking straight afterwards and takes
     * the colour from here rather than resolving it a second time.
     */
    @Override
    public void drawGraphElement(Graphics2D g2) {
        CanvasPalette palette = CanvasPalette.current();
        Color stroke = palette.strokeFor(getColor());
        g2.setStroke(new BasicStroke(getLineWidth()));
        g2.setColor(stroke);
        g2.draw(graphElement);
        g2.setColor(palette.get(
                linkedToAnotherPlace ? CanvasColor.LINKED_PLACE_FILL : CanvasColor.ELEMENT_FILL));
        g2.fill(graphElement);
        g2.setColor(stroke);
    }

    @Override
    public void setNewCoordinates(Point2D p) {
        graphElement.setFrame(
                p.getX() - (double) getDiameter() / 2,
                p.getY() - (double) getDiameter() / 2,
                getDiameter(), getDiameter()
        );
    }

    @Override
    public boolean isGraphElement(Point2D p) { return graphElement.contains(p); }

    @Override
    public Point2D getGraphElementCenter() {
        return new Point2D.Double(
                graphElement.getX() + (double) getDiameter() / 2,
                graphElement.getY() + (double) getDiameter() / 2
        );
    }

    @Override
    public String getType() { return graphElement.getClass().toString(); }

    @Override
    public int getBorder() { return getDiameter() / 2; }

    @Override
    public boolean isCircular() { return true; }

    @Override
    public Rectangle getBounds() { return graphElement.getBounds(); }

    public Ellipse2D getGraphElement() { return graphElement; }
    public void setGraphElement(Ellipse2D graphElement) { this.graphElement = graphElement; }
}
